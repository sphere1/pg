#import "ViewController.h"

UITextView *textView;

@interface ViewController ()

@end

@implementation ViewController

@synthesize _transaction;
@synthesize _request;
//@synthesize queue;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 600, 600)];
    
    [self.view addSubview:textView];
    
    [textView setText:@"test"];
    
    
    _request = [[BPNPaymentRequest alloc]
                initInvoiceNumber:@"1234"
                pnRefNum:nil
                amount:[NSDecimalNumber decimalNumberWithString:@"5.00"]
                tipAmount:[NSDecimalNumber decimalNumberWithString:@"1.00"]
                cashBackAmount:nil
                tenderType:TENDER_TYPE_CREDIT
                transactionType:TRANSACTION_TYPE_SALE
                username:@"paulpgtest"
                password:@"57!sE@3Fm"
                merchantCode:@"682000"
                merchantAccountCode:@"682001"
                paymentAccountNumber:nil
                token:nil
                expirationDate:nil
                terminalType:TERMINAL_TYPE_INGENICO_BLUETOOTH
                industryType:TRANSACTION_IN
                disableEmv:NO
                testMode:YES];
    
    /*
    _request = [[BPNPaymentRequest alloc] initWithAmount:[NSDecimalNumber decimalNumberWithString:@"5.00"]
                                               tipAmount:[NSDecimalNumber decimalNumberWithString:@"1.00"]
                                           invoiceNumber:@"1234"
                                              tenderType:TENDER_TYPE_CREDIT
                                         transactionType:TRANSACTION_TYPE_SALE
                                                username:@"paulpgtest"
                                                password:@"57!sE@3Fm"
                                            merchantCode:@"682000"
                                     merchantAccountCode:@"682001"
                                 originalReferenceNumber:nil
                                          cashBackAmount:nil
                                    paymentAccountNumber:nil
                                          expirationDate:nil
                                         shippingAddress:nil
                                              deviceType:TERMINAL_TYPE_INGENICO_BLUETOOTH
                                                testMode:YES
                                               withToken:nil
                                            industryType:TRANSACTION_INDUSTRY_TYPE_RESTAURANT];*/
    
    _transaction = [[PayGuardianTransaction alloc] initWithPaymentRequest:_request];
    
    [_transaction runOnCompletion: ^(BPNPayment *payment, NSError *error) {
        //process response
        
        
    } onStateChanged: ^(PayGuardianTransactionState state) {
        //process state change
       
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
